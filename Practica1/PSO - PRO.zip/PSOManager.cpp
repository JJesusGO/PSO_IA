#include "PSOManager.h"

PSOManager::PSOManager(PSO *pso,float valor,float error){
    this->porcentajes = NULL;
    this->error = error;
    this->valor = valor;
    this->pso = pso;
    this->n = 0;
}
PSOManager::~PSOManager(){
    if(this->porcentajes!=NULL)
        delete []this->porcentajes;
}
void PSOManager::Run(){

    int *iteraciones = NULL;
    if(this->n!=0)
        iteraciones = new int[this->n];
    for(int i=0;i<n;i++)
        iteraciones[i] = static_cast<int>((porcentajes[i]/100)*(pso->GetIteraciones()));
    int t = 0;
    printf("CALCULANDO...\n\n");
    while(pso->IsNextIteracion(valor,error,t)){
        pso->NextIteracion();
        for(int i=0;i<n;i++)
            if(t == iteraciones[i]){
                printf("-> %2.2f \% - (%i / %i)\n\n",porcentajes[i],t,pso->GetIteraciones());
                pso->MostrarMejorParticula();
                printf("\n\n");
            }
        t++;
    }
    printf("-> 100.00 \%(%i / %i)\n\n",pso->GetIteraciones(),pso->GetIteraciones());
    pso->MostrarMejorParticula();
    printf("\n");

}
void PSOManager::SetPorcentajes(float *porcentajes,int n){
    if(this->porcentajes!=NULL)
        delete []this->porcentajes;
    this->porcentajes = new float[n];
    for(int i=0;i<n;i++)
        this->porcentajes[i] = porcentajes[i];
        this->n = n;
}
