#include <iostream>
#include <cmath>
#include "Random.h"
#include "Particula.h"
#include "PSO.h"
#include "PSOManager.h"

float EvaluarEjemplo(Particula &particula){
    float suma = 0;
    for(unsigned int i=0;i<particula.GetDimensiones();i++)
        suma += particula.GetPosicion(i)*particula.GetPosicion(i);
    return (suma);
}
int ActualizarEjemplo(Particula &particula){
    if( fabs(particula.GetFitnessX()) < fabs(particula.GetFitnessP()))
        return 1;
    return 0;
}
int SeleccionarEjemplo(Particula &particula,Particula &mejor){
    if(fabs(particula.GetFitnessP()) < fabs(mejor.GetFitnessP()) )
        return 1;
    return 0;
}

void MostrarTelon(){
    printf("\n\n--------------------------------------\n\n");
}

int main(){

    Random::SetRandom();
    Random::SetSeed(Seed(6));

    int       t = 0;
    float  rmin[10],
           rmax[10];
    for(unsigned int i=0;i<10;i++){
        rmin[i] = -5.12f;
        rmax[i] =  5.12f;
    }
    float porcentajes[] = {0,25,50,75};

    PSO pso(100,rmin,rmax,10,500000);
        pso.SetFunciones(EvaluarEjemplo,ActualizarEjemplo,SeleccionarEjemplo);
        pso.IniciarEnjambre(1,1,-1,1);

    PSOManager  manager(&pso,0);
                manager.SetPorcentajes(porcentajes,4);

    pso.MostrarPSO();
    MostrarTelon();
    manager.Run();
    MostrarTelon();
    printf("%s",Random::GetSeed().GetSeedString().c_str());

    return 0;
}
